# Android release checklist

1. **Gateway must be HTTPS/WSS** in release builds. Debug permits cleartext only for LAN development.
2. Keep DeepSeek/Tencent/DUIX provider secrets on the Gateway/worker. The APK stores only the Gateway URL and the user's mobile token.
3. Before public launch replace the single `MOBILE_ACCESS_TOKEN` with user login + short-lived JWT + rate/usage limits.
4. Create a private Android signing keystore and store it outside the repository.
5. GitHub Actions signed release needs repository secrets:
   - `ANDROID_KEYSTORE_BASE64`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`
   - `ANDROID_STORE_PASSWORD`
6. Play Store upload uses the generated `app-release.aab`. Direct Android installation can use `app-release.apk`.
7. Microphone permission is requested at runtime. The WebView only grants audio capture to the configured Gateway origin.
