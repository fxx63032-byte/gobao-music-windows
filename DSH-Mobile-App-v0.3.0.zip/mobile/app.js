const $ = s => document.querySelector(s);
const app = $('#app');
const avatar = $('#avatar');
const caption = $('#caption');
const statusEl = $('#status');
const micBtn = $('#micBtn');
const soundBtn = $('#soundBtn');
const startBtn = $('#startBtn');
const tokenInput = $('#tokenInput');
const healthEl = $('#health');
const exitBtn = $('#exitBtn');

let token = localStorage.getItem('rh.mobile.token') || '';
tokenInput.value = token;
let muted = false;
let stream = null;
let recorder = null;
let chunks = [];
let audioCtx = null;
let analyser = null;
let vadTimer = null;
let inSpeech = false;
let lastVoiceAt = 0;
let history = [];
let busy = false;
let autoListen = false;
let pollTimer = null;

function authHeaders(extra={}) { return token ? {Authorization:`Bearer ${token}`,...extra}:extra; }
function setStatus(s){ statusEl.textContent=s; }
function setCaption(s){ caption.textContent=s || ' '; }

async function health(){
  try{
    const r=await fetch('/api/health'); const j=await r.json();
    healthEl.textContent=`Gateway ${j.ok?'在线':'异常'} · DSH ${j.dsh_bridge?'在线':'未连接'} · DeepSeek ${j.deepseek?'已配置':'未配置'}`;
  }catch(e){healthEl.textContent='Gateway 未连接';}
}
health();

async function enterFullScreen(){
  try{ window.RealHumanNative?.setImmersive?.(true); }catch(e){}
  try{ if(document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen(); }catch(e){}
  try{ if(screen.orientation?.lock) await screen.orientation.lock('portrait'); }catch(e){}
}


async function startConversation(){
  token=tokenInput.value.trim(); localStorage.setItem('rh.mobile.token',token);
  await enterFullScreen();
  app.classList.remove('idle'); app.classList.add('live');
  autoListen=true;
  try{
    await fetch('/api/mobile/dh/enable',{method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify({enabled:true})});
  }catch(e){}
  await ensureMic();
  beginListening();
  connectEvents();
}

async function ensureMic(){
  if(stream) return stream;
  stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
  audioCtx=new (window.AudioContext||window.webkitAudioContext)();
  const src=audioCtx.createMediaStreamSource(stream);
  analyser=audioCtx.createAnalyser(); analyser.fftSize=512; src.connect(analyser);
  return stream;
}

function rms(){
  if(!analyser) return 0;
  const a=new Uint8Array(analyser.fftSize); analyser.getByteTimeDomainData(a);
  let sum=0; for(const v of a){const n=(v-128)/128;sum+=n*n;} return Math.sqrt(sum/a.length);
}

function beginListening(){
  if(!stream || recorder?.state==='recording' || busy) return;
  chunks=[];
  let mime='';
  for(const t of ['audio/webm;codecs=opus','audio/webm','audio/mp4']){if(MediaRecorder.isTypeSupported(t)){mime=t;break;}}
  recorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);
  recorder.ondataavailable=e=>{if(e.data.size) chunks.push(e.data)};
  recorder.onstop=()=>submitSpeech(new Blob(chunks,{type:recorder.mimeType||'audio/webm'}));
  recorder.start(250);
  micBtn.classList.add('listening'); setStatus('正在听');
  inSpeech=false; lastVoiceAt=performance.now();
  clearInterval(vadTimer);
  vadTimer=setInterval(()=>{
    const level=rms(); const now=performance.now();
    if(level>0.035){inSpeech=true;lastVoiceAt=now;}
    if(inSpeech && now-lastVoiceAt>800 && recorder?.state==='recording'){
      clearInterval(vadTimer); recorder.stop(); micBtn.classList.remove('listening');
    }
  },80);
}

async function submitSpeech(blob){
  if(blob.size<1800){ if(autoListen) setTimeout(beginListening,250); return; }
  busy=true; setStatus('识别中');
  try{
    const fd=new FormData(); fd.append('audio',blob,'speech.webm');
    const sr=await fetch('/api/mobile/stt',{method:'POST',headers:authHeaders(),body:fd});
    if(!sr.ok) throw new Error(await sr.text());
    const stt=await sr.json(); const userText=(stt.text||'').trim();
    if(!userText){busy=false;if(autoListen)beginListening();return;}
    setCaption(userText); setStatus('思考中');
    const cr=await fetch('/api/mobile/chat',{method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify({text:userText,history})});
    if(!cr.ok) throw new Error(await cr.text());
    const cj=await cr.json(); const reply=(cj.text||'').trim();
    history.push({role:'user',content:userText},{role:'assistant',content:reply});history=history.slice(-20);
    setCaption(reply); setStatus('生成真人中');
    const sp=await fetch('/api/mobile/speak',{method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify({text:reply})});
    if(!sp.ok) throw new Error(await sp.text());
    const sj=await sp.json();
    if(sj.video_url) playRemoteVideo(sj.video_url); else pollDigitalHuman();
  }catch(e){
    console.error(e); setCaption('连接失败，请检查 Gateway / DSH 服务'); setStatus('错误'); busy=false; if(autoListen)setTimeout(beginListening,800);
  }
}

function playRemoteVideo(url){
  clearInterval(pollTimer);
  const proxy=`/api/mobile/media?url=${encodeURIComponent(url)}`;
  // video element cannot attach Authorization header; fetch securely then make a local object URL.
  fetch(proxy,{headers:authHeaders()}).then(r=>{if(!r.ok)throw new Error('video fetch');return r.blob()}).then(b=>{
    const local=URL.createObjectURL(b); avatar.loop=false; avatar.muted=muted; avatar.src=local;
    avatar.play().catch(()=>{}); setStatus('正在说话');
    avatar.onended=()=>{URL.revokeObjectURL(local);busy=false;setStatus('正在听');if(autoListen)beginListening();};
  }).catch(()=>{busy=false;if(autoListen)beginListening();});
}

function pollDigitalHuman(){
  clearInterval(pollTimer); let tries=0;
  pollTimer=setInterval(async()=>{
    tries++;
    try{
      const r=await fetch('/api/mobile/dh/status',{headers:authHeaders()}); const j=await r.json();
      if(j.video_url){clearInterval(pollTimer);playRemoteVideo(j.video_url);return;}
    }catch(e){}
    if(tries>180){clearInterval(pollTimer);busy=false;setStatus('生成超时');if(autoListen)beginListening();}
  },1000);
}

function connectEvents(){
  const scheme=location.protocol==='https:'?'wss':'ws';
  const ws=new WebSocket(`${scheme}://${location.host}/ws/events?token=${encodeURIComponent(token)}`);
  ws.onmessage=e=>{try{const m=JSON.parse(e.data);if(m.type==='ping')ws.send('pong')}catch(_){}};
}

micBtn.onclick=async()=>{
  if(recorder?.state==='recording'){clearInterval(vadTimer);recorder.stop();micBtn.classList.remove('listening');return;}
  await ensureMic();beginListening();
};
soundBtn.onclick=()=>{muted=!muted;avatar.muted=muted;soundBtn.style.opacity=muted?.45:1};
exitBtn.onclick=()=>{autoListen=false;clearInterval(vadTimer);clearInterval(pollTimer);if(recorder?.state==='recording')recorder.stop();document.exitFullscreen?.();app.classList.remove('live');app.classList.add('idle');};
exitBtn.addEventListener('dblclick',()=>{try{window.RealHumanNative?.openGatewaySettings?.()}catch(e){}});
startBtn.onclick=startConversation;
if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
