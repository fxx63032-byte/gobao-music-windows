from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, File, Header, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / "gateway" / ".env")

app = FastAPI(title="DSH Mobile Gateway", version="0.2.0")

origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

MOBILE = ROOT / "mobile"
app.mount("/assets", StaticFiles(directory=MOBILE), name="assets")

TOKEN = os.getenv("MOBILE_ACCESS_TOKEN", "").strip()
DSH = os.getenv("DSH_BRIDGE_URL", "http://127.0.0.1:8765").rstrip("/")
TIMEOUT = float(os.getenv("REQUEST_TIMEOUT_SECONDS", "180"))


def require_token(authorization: str | None) -> None:
    if not TOKEN:
        return
    if authorization != f"Bearer {TOKEN}":
        raise HTTPException(status_code=401, detail="invalid mobile token")


def extract_text(obj: Any) -> str:
    if isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        for key in ("text", "transcript", "result", "message", "content"):
            val = obj.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        for val in obj.values():
            out = extract_text(val)
            if out:
                return out
    if isinstance(obj, list):
        for val in obj:
            out = extract_text(val)
            if out:
                return out
    return ""


def extract_video_url(obj: Any) -> str | None:
    if isinstance(obj, dict):
        for key in ("video_url", "videoUrl", "url", "video"):
            val = obj.get(key)
            if isinstance(val, str) and (".mp4" in val or val.startswith("http")):
                return val
        for val in obj.values():
            got = extract_video_url(val)
            if got:
                return got
    if isinstance(obj, list):
        for val in obj:
            got = extract_video_url(val)
            if got:
                return got
    return None


class ChatIn(BaseModel):
    text: str
    history: list[dict[str, str]] = []


class SpeakIn(BaseModel):
    text: str


@app.get("/")
async def index():
    return FileResponse(MOBILE / "index.html")


@app.get("/manifest.webmanifest")
async def manifest():
    return FileResponse(MOBILE / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
async def service_worker():
    return FileResponse(MOBILE / "sw.js", media_type="application/javascript")


@app.get("/api/health")
async def health():
    bridge_ok = False
    detail: Any = None
    try:
        async with httpx.AsyncClient(timeout=4) as client:
            r = await client.get(f"{DSH}/api/health")
            bridge_ok = r.is_success
            try:
                detail = r.json()
            except Exception:
                detail = r.text[:300]
    except Exception as exc:
        detail = str(exc)
    return {
        "ok": True,
        "version": "0.2.0",
        "dsh_bridge": bridge_ok,
        "dsh_detail": detail,
        "deepseek": bool(os.getenv("DEEPSEEK_API_KEY", "").strip()),
        "auth_enabled": bool(TOKEN),
    }


@app.post("/api/mobile/stt")
async def mobile_stt(
    audio: UploadFile = File(...),
    authorization: str | None = Header(default=None),
):
    require_token(authorization)
    data = await audio.read()
    field = os.getenv("DSH_STT_FILE_FIELD", "file")
    files = {field: (audio.filename or "speech.webm", data, audio.content_type or "audio/webm")}
    path = os.getenv("DSH_STT_PATH", "/api/stt")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(f"{DSH}{path}", files=files)
    if not r.is_success:
        raise HTTPException(status_code=502, detail=f"DSH STT {r.status_code}: {r.text[:500]}")
    try:
        payload = r.json()
    except Exception:
        payload = {"text": r.text}
    return {"text": extract_text(payload), "raw": payload}


@app.post("/api/mobile/chat")
async def mobile_chat(body: ChatIn, authorization: str | None = Header(default=None)):
    require_token(authorization)
    key = os.getenv("DEEPSEEK_API_KEY", "").strip()
    if not key:
        raise HTTPException(status_code=503, detail="DEEPSEEK_API_KEY is not configured on gateway")
    base = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/")
    model = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
    system = os.getenv("SYSTEM_PROMPT", "你是一个实时语音助手。")
    messages: list[dict[str, str]] = [{"role": "system", "content": system}]
    for item in body.history[-12:]:
        role = item.get("role")
        content = item.get("content")
        if role in ("user", "assistant") and isinstance(content, str):
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": body.text})
    req = {"model": model, "messages": messages, "temperature": 0.65, "stream": False}
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(f"{base}/chat/completions", json=req, headers=headers)
    if not r.is_success:
        raise HTTPException(status_code=502, detail=f"DeepSeek {r.status_code}: {r.text[:500]}")
    payload = r.json()
    try:
        text = payload["choices"][0]["message"]["content"]
    except Exception:
        text = extract_text(payload)
    return {"text": text, "model": model}


@app.post("/api/mobile/speak")
async def mobile_speak(body: SpeakIn, authorization: str | None = Header(default=None)):
    require_token(authorization)
    path = os.getenv("DSH_DH_SPEAK_PATH", "/api/dh/speak")
    # DSH plugin uses this endpoint. Keep response pass-through so different upstream versions work.
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(f"{DSH}{path}", json={"text": body.text})
    if not r.is_success:
        raise HTTPException(status_code=502, detail=f"DUIX speak {r.status_code}: {r.text[:500]}")
    try:
        payload = r.json()
    except Exception:
        payload = {"raw": r.text}
    return {"raw": payload, "video_url": extract_video_url(payload)}


@app.get("/api/mobile/dh/status")
async def dh_status(authorization: str | None = Header(default=None)):
    require_token(authorization)
    path = os.getenv("DSH_DH_STATUS_PATH", "/api/dh/status")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.get(f"{DSH}{path}")
    if not r.is_success:
        raise HTTPException(status_code=502, detail=f"DUIX status {r.status_code}: {r.text[:500]}")
    try:
        payload = r.json()
    except Exception:
        payload = {"raw": r.text}
    return {"raw": payload, "video_url": extract_video_url(payload)}


@app.post("/api/mobile/dh/enable")
async def dh_enable(request: Request, authorization: str | None = Header(default=None)):
    require_token(authorization)
    path = os.getenv("DSH_DH_ENABLE_PATH", "/api/dh/enable")
    try:
        body = await request.json()
    except Exception:
        body = {"enabled": True}
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(f"{DSH}{path}", json=body)
    return Response(content=r.content, status_code=r.status_code, media_type=r.headers.get("content-type"))


@app.get("/api/mobile/media")
async def mobile_media(url: str, authorization: str | None = Header(default=None)):
    """Fetch a DUIX/bridge video through the gateway so the phone never needs LAN URLs.

    SSRF guard: only URLs whose host matches DSH_BRIDGE_URL or localhost/127.0.0.1 are accepted.
    """
    require_token(authorization)
    from urllib.parse import urlparse

    parsed = urlparse(url)
    dsh_host = urlparse(DSH).hostname
    allowed = {dsh_host, "127.0.0.1", "localhost"}
    if parsed.scheme not in ("http", "https") or parsed.hostname not in allowed:
        raise HTTPException(status_code=400, detail="media host is not allowed")
    async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as client:
        r = await client.get(url)
    if not r.is_success:
        raise HTTPException(status_code=502, detail=f"media fetch failed: {r.status_code}")
    return Response(content=r.content, media_type=r.headers.get("content-type", "video/mp4"))


@app.websocket("/ws/events")
async def ws_events(ws: WebSocket):
    token = ws.query_params.get("token", "")
    if TOKEN and token != TOKEN:
        await ws.close(code=4401)
        return
    await ws.accept()
    try:
        while True:
            # This channel is intentionally lightweight. It provides WSS keepalive and
            # future real-time status/events without exposing DSH internal ports.
            await ws.send_json({"type": "ping", "ts": int(time.time() * 1000)})
            try:
                msg = await ws.receive_text()
                if msg == "pong":
                    continue
            except Exception:
                pass
            await __import__("asyncio").sleep(15)
    except WebSocketDisconnect:
        pass


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "9443")))
