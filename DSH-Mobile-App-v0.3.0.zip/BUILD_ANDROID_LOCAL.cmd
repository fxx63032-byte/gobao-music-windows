@echo off
setlocal
cd /d "%~dp0android-app"
where gradle >nul 2>&1
if errorlevel 1 (
  echo Gradle command was not found.
  echo Easiest method: open android-app in Android Studio, wait for sync, then Build ^> Build APK(s).
  echo Or upload this project to GitHub and run Actions ^> Build Android APK.
  pause
  exit /b 1
)
gradle :app:assembleDebug --stacktrace
if errorlevel 1 goto fail
echo.
echo APK: android-app\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:fail
echo Build failed. Check Android SDK / Gradle output above.
pause
exit /b 1
