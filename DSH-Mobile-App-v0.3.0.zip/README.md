# DSH / RealHuman Mobile App v0.3.0

这一版把 v0.2 的 PWA + HTTPS/WSS Gateway 升级为 **Android 原生安装包工程**。原来的 DSH / FunASR / OmniVoice / DUIX / DeepSeek 服务端链路全部保留。

## 手机最终链路

```text
Android APP
  ↓ HTTPS / WSS
RealHuman Gateway
  ↓
DeepSeek + DSH voice_bridge
  ↓
FunASR / OmniVoice / DUIX
```

## 已实现的手机 APP 能力

- Android 原生 WebView 壳，包名 `com.realhuman.mobile`
- 首次启动填写自己的 **HTTPS Gateway URL**，以后自动记住
- 实时对话保持竖屏沉浸式全屏
- 状态栏 / 导航栏自动隐藏，滑动时临时出现
- Web 麦克风权限映射到 Android `RECORD_AUDIO`
- 只有你配置的 Gateway Origin 可以拿到麦克风权限
- 视频自动播放、全屏真人画面
- 保留 v0.2 的 34px 麦克风/音量视觉按钮和 44px 触摸热区
- 原生文件选择器已经接好，为后续“一张照片创建数字人”准备
- APP 内不保存 DeepSeek / 腾讯 / DUIX 主密钥
- 返回键提供：继续 / 服务器设置 / 退出
- Debug 允许局域网 HTTP；Release 强制 HTTPS

## 最快得到真正可安装 APK：GitHub Actions

把整个项目放进 GitHub 仓库，然后：

1. 打开 **Actions**
2. 选择 **Build Android APK**
3. 点 **Run workflow**
4. 构建结束下载 `RealHuman-debug-apk`
5. 解压得到 `app-debug.apk`，可直接安装到 Android 手机

这个 Debug APK 是 Android 自动调试签名的，适合内测。正式上线请运行 `Build Signed Android Release`。

## Android Studio 本地构建

打开 `android-app/`，等待 Gradle Sync，然后：

`Build → Build APK(s)`

输出位置：

```text
android-app/app/build/outputs/apk/debug/app-debug.apk
```

## 正式发布 APK / AAB

看 `ANDROID_RELEASE_CHECKLIST.md`。项目已包含签名 Release workflow。

## Gateway

沿用 v0.2：

1. 启动原 `dsh-voice-ai-girlfriend` 完整栈。
2. `gateway/.env.example` 复制为 `gateway/.env`。
3. 填 `MOBILE_ACCESS_TOKEN`、`DEEPSEEK_API_KEY`、`DSH_BRIDGE_URL`。
4. 运行 `deploy/start_gateway.cmd`。
5. 正式 APP 使用域名 HTTPS，例如 `https://ai.example.com`。

## iPhone

本包先把 **Android APK** 工程完整做通。iOS 安装包必须由 macOS + Xcode + Apple Developer 签名；Web/Gateway 代码无需重写，下一阶段只需要加 WKWebView 容器和 iOS 签名工程。
